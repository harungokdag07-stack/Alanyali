# Royale Ekran Tarayıcı (Android Studio proje başlangıcı)

## İçerik
Bu proje Android üzerinde `SYSTEM_ALERT_WINDOW` izniyle başka uygulamaların üstünde taşınabilir bir SCAN düğmesi gösteren **prototiptir**. Buton tıklanınca bilgilendirme penceresi açılır.

## Önemli sınır
Bu sürüm henüz ekran görüntüsü yakalamaz, OCR yapmaz, fiyat eşik kontrolü veya Telegram bildirimi göndermez. Bunlar için Android MediaProjection kullanıcı onayı, OCR kütüphanesi ve Telegram Bot API entegrasyonu ayrıca eklenmelidir. Oyunun ekranını izleme izni kullanıcı tarafından her oturumda onaylanmalıdır.

## APK derleme
1. Android Studio (Windows/Mac/Linux) kur.
2. `RoyaleFloatingScanner` klasörünü **Open** ile aç.
3. Gradle senkronizasyonunu tamamla (internet gerekebilir).
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. `app/build/outputs/apk/debug/app-debug.apk` dosyasını telefona kopyala ve kur.
6. Android Ayarlar'da uygulamaya "Üstte göster" iznini ver.
7. Uygulamayı aç > "Yüzen butonu başlat".

## Geliştirme notları
- Proje Java ve Android Gradle Plugin 8.7.3 kullanır.
- `minSdk 26`, `compileSdk 35`.
- Test edilmeden dağıtım APK'sı olarak kabul etmeyin.
