package com.royale.floating;

import android.app.*;
import android.content.*;
import android.graphics.PixelFormat;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.graphics.Color;

public class OverlayService extends Service {
  WindowManager wm; View bubble; WindowManager.LayoutParams params;
  @Override public void onCreate(){
    super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE);
    NotificationChannel ch=new NotificationChannel("overlay","Yüzen düğme",NotificationManager.IMPORTANCE_LOW);
    ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
    Notification n=new Notification.Builder(this,"overlay").setContentTitle("Royale Ekran Tarayıcı").setContentText("Yüzen düğme aktif").setSmallIcon(android.R.drawable.ic_menu_search).build();
    startForeground(7,n); addBubble();
  }
  void addBubble(){
    TextView t=new TextView(this); t.setText("SCAN"); t.setTextColor(Color.WHITE); t.setTextSize(13); t.setGravity(Gravity.CENTER);
    t.setBackgroundColor(Color.rgb(21,101,192)); t.setPadding(22,18,22,18); bubble=t;
    int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
    params=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
    params.gravity=Gravity.TOP|Gravity.START; params.x=40; params.y=250;
    wm.addView(bubble,params);
    t.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Royale Ekran Tarayıcı").setMessage("Yüzen düğme çalışıyor.\nBu prototip henüz ekran görüntüsü alıp OCR ile fiyat okuyamaz. Sonraki aşamada MediaProjection ekran izni ve OCR eklenmelidir.").setPositiveButton("Tamam",null).show());
    t.setOnTouchListener(new View.OnTouchListener(){int sx,sy,wx,wy; boolean moved;
      public boolean onTouch(View v,MotionEvent e){switch(e.getAction()){
        case MotionEvent.ACTION_DOWN:sx=(int)e.getRawX();sy=(int)e.getRawY();wx=params.x;wy=params.y;moved=false;return true;
        case MotionEvent.ACTION_MOVE:params.x=wx+(int)e.getRawX()-sx;params.y=wy+(int)e.getRawY()-sy;wm.updateViewLayout(bubble,params);moved=true;return true;
        case MotionEvent.ACTION_UP:if(!moved)v.performClick();return true;}return false;}});
  }
  @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
  @Override public void onDestroy(){if(bubble!=null)wm.removeView(bubble);super.onDestroy();}
  @Override public IBinder onBind(Intent i){return null;}
}
