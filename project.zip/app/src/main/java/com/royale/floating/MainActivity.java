package com.royale.floating;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(36,40,36,30);
    TextView title = new TextView(this); title.setText("Royale Ekran Tarayıcı"); title.setTextSize(24);
    TextView info = new TextView(this); info.setText("\nBu başlangıç sürümü oyun üstünde yüzen kontrol düğmesi sağlar. Android ekran görüntüsü izni (MediaProjection) ve OCR analiz modülü sonraki entegrasyon aşamasıdır.\n\n1) Önce 'Üstte göster' iznini aç.\n2) Yüzen düğmeyi başlat.\n3) Royale Online'a geç ve düğmeye dokun.\n"); info.setTextSize(16);
    Button permission = new Button(this); permission.setText("Üstte göster iznini aç");
    permission.setOnClickListener(v -> { if(!Settings.canDrawOverlays(this)) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); });
    Button start = new Button(this); start.setText("Yüzen butonu başlat");
    start.setOnClickListener(v -> { if(Settings.canDrawOverlays(this)){ startForegroundService(new Intent(this, OverlayService.class)); } else { permission.performClick(); } });
    Button stop = new Button(this); stop.setText("Yüzen butonu kapat"); stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));
    root.addView(title); root.addView(info); root.addView(permission); root.addView(start); root.addView(stop);
    setContentView(root);
  }
}
