package com.alanyali.royalescanner
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.*
import android.widget.TextView
object Floating{
 private var view:View?=null;private var wm:WindowManager?=null
 fun start(c:Context){if(view!=null)return;wm=c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
  val v=TextView(c).apply{text="●";textSize=30f;setTextColor(0xffffffff.toInt());setBackgroundColor(0xaa9b1600.toInt());gravity=Gravity.CENTER;setOnClickListener{ScanAccessibilityService.startLoop(c)};setOnLongClickListener{ScanAccessibilityService.stopLoop();true}}
  val type=if(Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
  val p=WindowManager.LayoutParams(65,65,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.START;x=40;y=250}
  v.setOnTouchListener(object:View.OnTouchListener{var sx=0f;var sy=0f;var ox=0;var oy=0;override fun onTouch(v:View,e:MotionEvent):Boolean{when(e.action){0->{sx=e.rawX;sy=e.rawY;ox=p.x;oy=p.y};2->{p.x=ox+(e.rawX-sx).toInt();p.y=oy+(e.rawY-sy).toInt();wm?.updateViewLayout(v,p)}};return false}})
  wm?.addView(v,p);view=v
 }
}