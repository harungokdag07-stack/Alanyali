package com.alanyali.royalescanner

import android.app.*
import android.content.*
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*

class MainActivity : Activity() {
    private lateinit var keyword: EditText
    private lateinit var maxPrice: EditText
    private lateinit var interval: EditText
    private lateinit var searchX: EditText
    private lateinit var searchY: EditText
    private lateinit var itemX: EditText
    private lateinit var itemY: EditText
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
        val root=LinearLayout(this).apply{orientation=1;setPadding(24,20,24,20)}
        root.addView(TextView(this).apply{text="Royale Ekran Tarayıcı";textSize=22f})
        root.addView(TextView(this).apply{text="Ürün adı OCR'de aranır; fiyat sınırının altındaysa hedef koordinata dokunur. Önce oyunda Dükkan/Arama ekranını aç."})
        keyword=field(root,"Ürün adı / anahtar kelime", "keyword","Leylak")
        maxPrice=field(root,"En yüksek fiyat (rakam)", "price","4500000")
        interval=field(root,"Arama yenileme aralığı (dakika)", "interval","10")
        searchX=field(root,"Ara butonu X", "sx","336"); searchY=field(root,"Ara butonu Y","sy","611")
        itemX=field(root,"İlan/ürün dokunma X","ix","700"); itemY=field(root,"İlan/ürün dokunma Y","iy","200")
        val overlay=Button(this).apply{text="Yuvarlak kayan düğmeyi göster";setOnClickListener{
            if(!Settings.canDrawOverlays(this@MainActivity)){startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))}
            else {Floating.start(this@MainActivity);status.text="Kayan düğme açıldı"}
        }}
        root.addView(overlay)
        root.addView(Button(this).apply{text="Erişilebilirlik iznini aç";setOnClickListener{startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))}})
        root.addView(Button(this).apply{text="Taramayı başlat";setOnClickListener{save();ScanAccessibilityService.startLoop(this@MainActivity);status.text="Tarama başlatıldı"}})
        root.addView(Button(this).apply{text="Durdur";setOnClickListener{ScanAccessibilityService.stopLoop();status.text="Durduruldu"}})
        status=TextView(this).apply{text="Durum: hazır";textSize=16f};root.addView(status)
        setContentView(ScrollView(this).apply{addView(root)})
    }
    private fun field(root:LinearLayout,label:String,key:String,def:String):EditText{
        root.addView(TextView(this).apply{text=label})
        val e=EditText(this).apply{setText(prefs.getString(key,def));singleLine=true}
        root.addView(e);return e
    }
    private fun save(){prefs.edit().putString("keyword",keyword.text.toString()).putString("price",maxPrice.text.toString()).putString("interval",interval.text.toString()).putString("sx",searchX.text.toString()).putString("sy",searchY.text.toString()).putString("ix",itemX.text.toString()).putString("iy",itemY.text.toString()).apply()}
}