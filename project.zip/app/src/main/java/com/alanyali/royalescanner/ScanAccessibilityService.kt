package com.alanyali.royalescanner

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.*
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.accessibilityservice.GestureDescription
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class ScanAccessibilityService: AccessibilityService(){
 override fun onAccessibilityEvent(event:AccessibilityEvent?) {}
 override fun onInterrupt() {}
 override fun onServiceConnected(){ instance=this }
 companion object{
  @Volatile var instance:ScanAccessibilityService?=null
  private var scheduler:java.util.concurrent.ScheduledExecutorService?=null
  fun startLoop(c:android.content.Context){scheduler?.shutdownNow(); val mins=c.getSharedPreferences("cfg",0).getString("interval","10")?.toLongOrNull()?.coerceIn(1,1440)?:10
   scheduler=Executors.newSingleThreadScheduledExecutor().also{it.scheduleAtFixedRate({instance?.scan()},0,mins,TimeUnit.MINUTES)}
  }
  fun stopLoop(){scheduler?.shutdownNow();scheduler=null}
 }
 private fun tap(x:Float,y:Float){val p=android.graphics.Path().apply{moveTo(x,y)};val g=GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p,0,100)).build();dispatchGesture(g,null,null)}
 fun scan(){
  if(Build.VERSION.SDK_INT<30)return
  takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object:TakeScreenshotCallback{
   override fun onSuccess(s:android.accessibilityservice.AccessibilityService.ScreenshotResult){
    val hw=s.hardwareBuffer; val bmp=Bitmap.wrapHardwareBuffer(hw,s.colorSpace); hw.close()
    if(bmp!=null) recognize(bmp)
   }
   override fun onFailure(errorCode:Int){}
  })
 }
 private fun recognize(bitmap:Bitmap){
  val cfg=getSharedPreferences("cfg",0);val keyword=cfg.getString("keyword","")!!.lowercase()
  val max=cfg.getString("price","0")!!.replace(".","").replace(",","").toLongOrNull()?:0
  val recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
  recognizer.process(InputImage.fromBitmap(bitmap,0)).addOnSuccessListener { result->
   val all=result.text.lowercase()
   // Product and numeric price must both appear in captured screen; tap configured item point only on match.
   val nums=Regex("[0-9][0-9.,]*").findAll(all).mapNotNull{it.value.replace(".","").replace(",","").toLongOrNull()}.toList()
   if(keyword.isNotBlank() && all.contains(keyword) && nums.any{it<=max}){
    val x=cfg.getString("ix","700")!!.toFloatOrNull()?:700f;val y=cfg.getString("iy","200")!!.toFloatOrNull()?:200f
    tap(x,y)
   }else{
    val x=cfg.getString("sx","336")!!.toFloatOrNull()?:336f;val y=cfg.getString("sy","611")!!.toFloatOrNull()?:611f
    tap(x,y)
   }
   recognizer.close()
  }.addOnFailureListener{recognizer.close()}
 }
}